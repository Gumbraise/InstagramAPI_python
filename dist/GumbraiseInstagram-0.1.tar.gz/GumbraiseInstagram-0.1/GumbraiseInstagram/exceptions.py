class SentryBlockException(Exception):
    pass